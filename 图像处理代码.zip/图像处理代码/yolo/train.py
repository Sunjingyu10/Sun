

# from ultralytics import RTDETR
# import warnings
# warnings.filterwarnings('ignore')

# model = RTDETR(r"/root/autodl-tmp/rtdetr-200/yolov11-main/ultralytics/cfg/models/rt-detr/rtdetr-l.yaml")
# # model.load('yolo11n.pt')

# results = model.train(data=r"/root/autodl-tmp/rtdetr-200/yolov11-main/data/data.yaml", imgsz=640, epochs=200, cache=True,batch=16, device=0, optimizer="AdamW", workers=12,lr0=0.001)
# metrics=model.val()



from ultralytics import YOLO
import warnings
warnings.filterwarnings('ignore')

model = YOLO(r"/root/autodl-tmp/rtdetr-200/yolov11-main/ultralytics/cfg/models/v5/yolov5m.yaml")
# model.load('yolo11n.pt')

results = model.train(data=r"/root/autodl-tmp/rtdetr-200/yolov11-main/data/data.yaml", imgsz=640, epochs=200, cache=True,batch=16, device=0, optimizer="SGD", workers=12,iou=0.9)
metrics=model.val()










