from flask import Flask, render_template, request, jsonify, send_from_directory
from ultralytics import YOLO
import cv2
import numpy as np
from PIL import Image
import os
import uuid  # 生成唯一文件名，避免冲突

# 初始化Flask应用
app = Flask(__name__)

# 配置路径（根据实际情况调整）
APP_ROOT = os.path.dirname(os.path.abspath(__file__))  # 项目根路径
UPLOAD_FOLDER = os.path.join(APP_ROOT, 'uploads')  # 上传图片保存路径
MODEL_PATH = os.path.join(APP_ROOT, 'models', 'best.pt')  # YOLO模型路径
os.makedirs(UPLOAD_FOLDER, exist_ok=True)  # 自动创建uploads文件夹


# 初始化蜜蜂检测器（封装YOLO逻辑）
class BeeDetector:
    def __init__(self, model_path=MODEL_PATH):
        self.model = self.load_model(model_path)
        self.class_names = {0: 'bee'}  # 模型类别（根据你的训练结果调整）
        self.colors = {'bee': (0, 255, 255)}  # 蜜蜂框：黄色

    def load_model(self, model_path):
        """加载YOLO模型"""
        try:
            model = YOLO(model_path)
            print(f"✅ YOLO模型加载成功: {model_path}")
            return model
        except Exception as e:
            raise Exception(f"❌ 模型加载失败: {str(e)}")

    def detect_and_draw(self, image_path, conf_threshold=0.5):
        """检测蜜蜂并绘制边界框，返回结果图片路径和统计信息"""
        # 1. 读取图片
        if not os.path.exists(image_path):
            raise Exception(f"❌ 图片不存在: {image_path}")
        image = Image.open(image_path).convert('RGB')
        img_array = np.array(image)

        # 2. YOLO推理
        results = self.model(img_array, conf=conf_threshold)

        # 3. 解析结果+绘制边界框
        detections = []
        img_cv = img_array.copy()  # 用于绘制的OpenCV格式图片

        for i, result in enumerate(results):
            for box in result.boxes:
                # 提取检测信息
                x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())  # 边界框（左上-右下）
                conf = float(box.conf)  # 置信度
                class_id = int(box.cls)  # 类别ID
                class_name = self.class_names.get(class_id, 'unknown')

                # 保存检测详情
                detections.append({
                    "id": i + 1,
                    "class": class_name,
                    "confidence": round(conf, 3),
                    "bbox": [x1, y1, x2, y2],
                    "size": f"{x2 - x1}×{y2 - y1}px",
                    "area": (x2 - x1) * (y2 - y1)
                })

                # 绘制边界框
                color = self.colors.get(class_name, (0, 255, 0))  # 默认绿色
                cv2.rectangle(img_cv, (x1, y1), (x2, y2), color, 3)

                # 绘制标签（带背景）
                label = f"{class_name} {conf:.2f}"
                (text_w, text_h), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)
                cv2.rectangle(img_cv, (x1, y1 - text_h - 10), (x1 + text_w, y1), color, -1)  # 标签背景
                cv2.putText(img_cv, label, (x1, y1 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)

                # 绘制蜜蜂序号
                cv2.putText(img_cv, str(i + 1), (x2 - 20, y1 + 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)

        # 4. 保存结果图片（用唯一文件名避免覆盖）
        result_filename = f"result_{uuid.uuid4().hex}.jpg"  # 唯一文件名
        result_path = os.path.join(UPLOAD_FOLDER, result_filename)
        # 转换颜色空间（OpenCV默认BGR，PIL需要RGB）
        img_result = Image.fromarray(cv2.cvtColor(img_cv, cv2.COLOR_BGR2RGB))
        img_result.save(result_path)

        # 5. 返回结果（前端需要的信息）
        return {
            "original_image": os.path.basename(image_path),  # 原文件名
            "result_image_path": result_filename,  # 结果图片文件名（用于前端加载）
            "bee_count": len(detections),  # 蜜蜂总数
            "detections": detections,  # 每只蜜蜂的详情
            "conf_threshold": conf_threshold  # 置信度阈值
        }


# 初始化检测器（全局单例，避免重复加载模型）
try:
    detector = BeeDetector()
except Exception as e:
    print(f"⚠️ 初始化检测器失败，服务可能无法正常工作: {str(e)}")
    detector = None


# ------------------- Flask路由 -------------------
@app.route('/')
def index():
    """首页：显示文件选择和结果展示区域"""
    return render_template('index.html')


@app.route('/upload', methods=['POST'])
def upload_image():
    """处理图片上传和检测请求"""
    if detector is None:
        return jsonify({"status": "error", "msg": "检测器初始化失败，请检查模型路径"})

    # 1. 接收上传的文件
    if 'image' not in request.files:
        return jsonify({"status": "error", "msg": "未选择图片文件"})

    file = request.files['image']
    if file.filename == '':
        return jsonify({"status": "error", "msg": "请选择有效的图片文件"})

    # 2. 验证文件格式（仅允许图片）
    allowed_extensions = {'png', 'jpg', 'jpeg', 'bmp'}
    if not file.filename.lower().rsplit('.', 1)[1] in allowed_extensions:
        return jsonify({"status": "error", "msg": "仅支持PNG/JPG/JPEG/BMP格式"})

    # 3. 保存上传的图片到uploads文件夹
    unique_filename = f"upload_{uuid.uuid4().hex}_{file.filename}"  # 唯一文件名
    upload_path = os.path.join(UPLOAD_FOLDER, unique_filename)
    file.save(upload_path)

    # 4. 调用检测器处理图片
    try:
        conf_threshold = float(request.form.get('conf_threshold', 0.5))  # 从前端获取置信度阈值
        detection_result = detector.detect_and_draw(upload_path, conf_threshold)
        return jsonify({
            "status": "success",
            "data": detection_result
        })
    except Exception as e:
        return jsonify({"status": "error", "msg": f"检测失败: {str(e)}"})


@app.route('/uploads/<filename>')
def serve_uploaded_file(filename):
    """提供uploads文件夹中图片的访问（前端加载图片用）"""
    return send_from_directory(UPLOAD_FOLDER, filename)


# 启动服务
if __name__ == '__main__':
    app.run(debug=True)  # 开发环境用debug模式，生产环境需关闭