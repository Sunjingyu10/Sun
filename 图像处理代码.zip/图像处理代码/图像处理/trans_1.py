import math
import cv2
import numpy as np
from PIL import Image, ImageEnhance
import os
from pathlib import Path
from tqdm import tqdm
import random


class YOLOImageAugmentor:
    def __init__(self):
        pass

    @staticmethod
    def flip(image, annotations):
        """水平翻转 - 保持目标位置关系"""
        flipped_image = image.transpose(Image.FLIP_LEFT_RIGHT)

        # 更新标注：x坐标翻转
        flipped_annotations = []
        for ann in annotations:
            parts = ann.strip().split()
            if len(parts) >= 5:
                class_id, x_center, y_center, width, height = parts
                new_x_center = 1.0 - float(x_center)
                flipped_annotations.append(f"{class_id} {new_x_center:.6f} {y_center} {width} {height}")

        return flipped_image, flipped_annotations

    @staticmethod
    def rotation(image, annotations, angle=90):
        """90度旋转"""
        rotated_image = image.rotate(angle, expand=True)

        # 旋转后图像尺寸可能变化
        orig_width, orig_height = image.size
        new_width, new_height = rotated_image.size

        rotated_annotations = []
        for ann in annotations:
            parts = ann.strip().split()
            if len(parts) >= 5:
                class_id, x_center, y_center, width, height = parts
                x_center, y_center = float(x_center), float(y_center)
                width, height = float(width), float(height)

                # 计算旋转后的坐标（简化处理，实际需要更复杂的变换）
                if angle == 90:
                    new_x = y_center
                    new_y = 1.0 - x_center
                    new_w = height
                    new_h = width
                elif angle == 180:
                    new_x = 1.0 - x_center
                    new_y = 1.0 - y_center
                    new_w = width
                    new_h = height
                elif angle == 270:
                    new_x = 1.0 - y_center
                    new_y = x_center
                    new_w = height
                    new_h = width

                rotated_annotations.append(f"{class_id} {new_x:.6f} {new_y:.6f} {new_w:.6f} {new_h:.6f}")

        return rotated_image, rotated_annotations

    @staticmethod
    def brightness_contrast(image, annotations):
        """亮度和对比度增强 - 不需要更新标注"""
        brightness_factor = random.uniform(0.8, 1.3)
        contrast_factor = random.uniform(0.9, 1.4)

        enh_bri = ImageEnhance.Brightness(image)
        enhanced_image = enh_bri.enhance(brightness_factor)

        enh_con = ImageEnhance.Contrast(enhanced_image)
        enhanced_image = enh_con.enhance(contrast_factor)

        return enhanced_image, annotations  # 标注不变

    @staticmethod
    def hsv_augmentation(image, annotations):
        """HSV颜色空间增强 - 不需要更新标注"""
        img_array = np.array(image)
        img_bgr = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR)

        h_gain = random.uniform(0.01, 0.1)
        s_gain = random.uniform(0.1, 0.3)
        v_gain = random.uniform(0.1, 0.3)

        r = np.random.uniform(-1, 1, 3) * [h_gain, s_gain, v_gain] + 1

        hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV).astype(np.float32)
        h, s, v = cv2.split(hsv)

        h = (h * r[0]) % 180
        s = np.clip(s * r[1], 0, 255)
        v = np.clip(v * r[2], 0, 255)

        hsv = cv2.merge([h, s, v]).astype(np.uint8)
        aug_img = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)
        enhanced_image = Image.fromarray(cv2.cvtColor(aug_img, cv2.COLOR_BGR2RGB))

        return enhanced_image, annotations  # 标注不变

    @staticmethod
    def blur(image, annotations):
        """轻度高斯模糊 - 不需要更新标注"""
        img_array = np.array(image)
        kernel_size = random.choice([3, 5])
        blurred = cv2.GaussianBlur(img_array, (kernel_size, kernel_size), 0)
        enhanced_image = Image.fromarray(blurred)

        return enhanced_image, annotations  # 标注不变

    @staticmethod
    def read_annotations(annotation_path):
        """读取标注文件"""
        if os.path.exists(annotation_path):
            with open(annotation_path, 'r', encoding='utf-8') as f:
                return f.readlines()
        return []

    @staticmethod
    def save_annotations(annotation_path, annotations):
        """保存标注文件"""
        with open(annotation_path, 'w', encoding='utf-8') as f:
            for ann in annotations:
                f.write(ann + '\n')

    @staticmethod
    def augment_image(image_path, label_dir, save_image_dir, save_label_dir):
        """对单张图像应用增强方法"""
        try:
            image = Image.open(image_path)
            base_name = Path(image_path).stem
            extension = Path(image_path).suffix

            # 读取对应的标注文件
            annotation_path = os.path.join(label_dir, f"{base_name}.txt")
            original_annotations = YOLOImageAugmentor.read_annotations(annotation_path)

            # 应用增强方法
            augmentations = []

            # 1. 水平翻转
            flipped_image, flipped_anns = YOLOImageAugmentor.flip(image.copy(), original_annotations)
            augmentations.append(("flip", flipped_image, flipped_anns))

            # 2. 旋转 (90度)
            rotated_image, rotated_anns = YOLOImageAugmentor.rotation(image.copy(), original_annotations, 90)
            augmentations.append(("rotate90", rotated_image, rotated_anns))

            # 3. 亮度对比度调整 (不需要更新标注)
            bc_image, bc_anns = YOLOImageAugmentor.brightness_contrast(image.copy(), original_annotations)
            augmentations.append(("bc", bc_image, bc_anns))

            # 4. HSV颜色增强 (不需要更新标注)
            hsv_image, hsv_anns = YOLOImageAugmentor.hsv_augmentation(image.copy(), original_annotations)
            augmentations.append(("hsv", hsv_image, hsv_anns))

            # 5. 轻度模糊 (不需要更新标注)
            blur_image, blur_anns = YOLOImageAugmentor.blur(image.copy(), original_annotations)
            augmentations.append(("blur", blur_image, blur_anns))

            # 保存增强后的图像和标注
            for method, enhanced_image, enhanced_annotations in augmentations:
                # 保存图像
                image_save_name = f"{base_name}_{method}{extension}"
                image_save_path = os.path.join(save_image_dir, image_save_name)
                enhanced_image.save(image_save_path)

                # 保存标注
                label_save_name = f"{base_name}_{method}.txt"
                label_save_path = os.path.join(save_label_dir, label_save_name)
                YOLOImageAugmentor.save_annotations(label_save_path, enhanced_annotations)

            return True

        except Exception as e:
            print(f"处理图像 {image_path} 时出错: {e}")
            return False

    @staticmethod
    def augment_directory(image_dir):
        """增强整个目录中的图像"""
        image_dir = Path(image_dir)

        if not image_dir.exists():
            print(f"错误: 图像目录 {image_dir} 不存在!")
            return

        # 检查标注目录是否存在
        label_dir = image_dir.parent / "labels"
        if not label_dir.exists():
            print(f"错误: 标注目录 {label_dir} 不存在!")
            print("请确保标注文件在: C:\\Users\\Sunjingyu\\Desktop\\Bee_Data\\Bee_Data\\data\\train\\labels\\")
            return

        # 创建保存目录
        augmented_image_dir = image_dir.parent / "augmented_images"
        augmented_label_dir = image_dir.parent / "augmented_labels"

        augmented_image_dir.mkdir(exist_ok=True)
        augmented_label_dir.mkdir(exist_ok=True)

        # 获取所有图像文件
        image_extensions = {".jpg", ".jpeg", ".png", ".bmp"}
        image_files = [f for f in image_dir.iterdir() if f.suffix.lower() in image_extensions and f.is_file()]

        if not image_files:
            print(f"在目录 {image_dir} 中未找到图像文件!")
            return

        print(f'找到 {len(image_files)} 张图像')
        print(f'标注目录: {label_dir}')
        print('开始增强处理...')
        print('=' * 50)

        # 处理每张图像
        success_count = 0
        for image_path in tqdm(image_files, desc="处理进度"):
            if YOLOImageAugmentor.augment_image(
                    image_path, label_dir, augmented_image_dir, augmented_label_dir
            ):
                success_count += 1

        print('=' * 50)
        print(f'处理完成! 成功增强 {success_count}/{len(image_files)} 张图像')
        print(f'增强图像保存在: {augmented_image_dir}')
        print(f'增强标注保存在: {augmented_label_dir}')


def main():
    """主函数"""
    image_dir = r"C:\Users\Sunjingyu\Desktop\Bee_Data\Bee_Data\data\train\images"

    print("YOLO训练图像增强工具")
    print("=" * 50)
    print(f"图像目录: {image_dir}")
    print("标注目录应该位于: C:\\Users\\Sunjingyu\\Desktop\\Bee_Data\\Bee_Data\\data\\train\\labels\\")
    print("=" * 50)

    # 确认操作
    response = input("确认开始处理吗? (y/n): ")
    if response.lower() != 'y':
        print("操作已取消")
        return

    # 处理目录
    augmentor = YOLOImageAugmentor()
    augmentor.augment_directory(image_dir)


if __name__ == "__main__":
    main()